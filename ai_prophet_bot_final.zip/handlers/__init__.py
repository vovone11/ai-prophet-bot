
from .quiz import register_handlers
